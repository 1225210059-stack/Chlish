import os
import sys
import argparse
import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import gradio as gr
from vllm import LLM, SamplingParams

# ===================== 全局配置 =====================
ROOT_CB_PATH = "./test_cipher_books/test_master.root.cb"
ENV_CB_PATH = "./test_cipher_books/test_target.env.cb"
SHARD_CB_PATHS = [f"./test_cipher_books/map_{i+1}.shard.cb" for i in range(5)]
MODEL_RAW_PATH = "./model_raw"
MODEL_ENCRYPTED_PATH = "./model_encrypted"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# 全局实例
llm = None
tokenizer = None
mx_model_crypto = None
inference_obfuscator = None
app = FastAPI(title="Chlish大模型API", version="1.2.0")

# 推理采样参数
sampling_params = SamplingParams(
    temperature=0.7,
    top_p=0.95,
    max_tokens=2048,
    repetition_penalty=1.1,
    skip_special_tokens=True
)

# ===================== 动态量化配置 =====================
def get_bnb_config():
    """自动检测显存，选择最优量化方案"""
    if not torch.cuda.is_available():
        return None
    total_vram = torch.cuda.get_device_properties(0).total_memory / 1024**3
    if total_vram >= 16:
        from transformers import BitsAndBytesConfig
        return BitsAndBytesConfig(
            load_in_8bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16
        )
    elif 8 <= total_vram < 16:
        from transformers import BitsAndBytesConfig
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16
        )
    else:
        from transformers import BitsAndBytesConfig
        return BitsAndBytesConfig(
            load_in_2bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16
        )

# ===================== MX加密体系初始化 =====================
def init_mx_crypto():
    """初始化CRYPTORAD-MX加密体系，环境校验"""
    global mx_model_crypto
    from modules.model_crypto import MXModelCrypto
    try:
        mx_model_crypto = MXModelCrypto(ROOT_CB_PATH, ENV_CB_PATH)
        print("✅ CRYPTORAD-MX加密体系初始化完成")
        return True
    except Exception as e:
        print(f"❌ MX加密体系初始化失败：{str(e)}，触发蜜罐模式")
        return False

# ===================== 模型加载 =====================
def load_model():
    """vLLM高速推理模型加载，支持MX加密权重"""
    global llm, tokenizer, inference_obfuscator
    init_mx_crypto()
    bnb_config = get_bnb_config()

    print(f"正在加载Chlish大模型 v1.2.0，设备：{DEVICE}")
    # 已加密权重加载
    if os.path.exists(MODEL_ENCRYPTED_PATH) and mx_model_crypto is not None and not mx_model_crypto.honey_mode:
        model, tokenizer = mx_model_crypto.decrypt_and_load_model(SHARD_CB_PATHS)
        llm = LLM(
            model=model,
            tokenizer=tokenizer,
            tensor_parallel_size=1,
            gpu_memory_utilization=0.9,
            quantization="4bit" if bnb_config else "8bit",
            trust_remote_code=True,
            device=DEVICE
        )
    # 原生模型加载，自动执行MX加密
    else:
        base_model = "Qwen/Qwen2.5-7B-Instruct-GGUF"
        llm = LLM(
            model=base_model,
            tensor_parallel_size=1,
            gpu_memory_utilization=0.9,
            quantization="4bit",
            trust_remote_code=True,
            device=DEVICE
        )
        tokenizer = llm.get_tokenizer()
        # 自动执行权重加密
        if mx_model_crypto is not None and not mx_model_crypto.honey_mode:
            os.makedirs(MODEL_RAW_PATH, exist_ok=True)
            llm.model.save_pretrained(MODEL_RAW_PATH)
            tokenizer.save_pretrained(MODEL_RAW_PATH)
            mx_model_crypto.encrypt_model_weights()

    # 初始化推理混淆器
    from modules.inference_obfuscator import MXInferenceObfuscator
    inference_obfuscator = MXInferenceObfuscator(tokenizer)
    print("✅ Chlish大模型加载完成，已就绪")
    return llm, tokenizer

# ===================== 核心生成函数 =====================
def generate_text(prompt: str, temperature: float = 0.7, max_new_tokens: int = 512):
    """核心生成函数，内置一次一密混淆与对抗水印"""
    global llm, tokenizer, inference_obfuscator
    if llm is None:
        load_model()
    # 蜜罐模式处理
    if mx_model_crypto is not None and mx_model_crypto.honey_mode:
        return "[蜜罐模式] 环境校验失败，输出无效结果"
    # 1. 生成一次一密混淆规则
    inference_obfuscator.generate_otp_mapping()
    # 2. 格式化prompt
    messages = [{"role": "user", "content": prompt}]
    formatted_prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    # 3. 推理生成
    current_sampling_params = sampling_params.clone()
    current_sampling_params.temperature = temperature
    current_sampling_params.max_tokens = max_new_tokens
    outputs = llm.generate(formatted_prompt, current_sampling_params)
    response = outputs[0].outputs[0].text
    # 4. 添加对抗性隐形水印
    watermarked_response = inference_obfuscator.add_adversarial_watermark(response)
    # 5. 销毁一次性密码本
    inference_obfuscator.destroy_otp()
    return watermarked_response

# ===================== FastAPI API接口 =====================
class GenerateRequest(BaseModel):
    prompt: str
    temperature: float = 0.7
    max_new_tokens: int = 512

@app.post("/api/generate")
async def api_generate(req: GenerateRequest):
    try:
        response = generate_text(req.prompt, req.temperature, req.max_new_tokens)
        return {"code": 200, "response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def api_health():
    return {"code": 200, "status": "running", "version": "1.2.0", "device": DEVICE}

# ===================== Gradio Web界面 =====================
def gradio_chat(prompt, history):
    return generate_text(prompt)

def start_gradio():
    with gr.Blocks(title="Chlish 自生长大模型 v1.2.0") as demo:
        gr.Markdown("# Chlish 自生长大模型 v1.2.0 旗舰版\n原生融合CRYPTORAD-MX最高安全架构 | 本地离线部署 | 军用级抗攻击")
        gr.ChatInterface(gradio_chat, title="对话界面")
    demo.launch(server_name="0.0.0.0", server_port=7860, inbrowser=True)

# ===================== 命令行对话模式 =====================
def start_cli():
    print("=== Chlish大模型 v1.2.0 命令行对话模式，输入exit退出 ===")
    while True:
        user_input = input("你：")
        if user_input.lower() in ["exit", "quit", "退出"]:
            break
        response = generate_text(user_input)
        print(f"Chlish：{response}")

# ===================== 主入口 =====================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Chlish大模型 v1.2.0 启动脚本")
    parser.add_argument("--api", action="store_true", help="启动FastAPI API服务")
    parser.add_argument("--web", action="store_true", help="启动Gradio可视化Web界面")
    parser.add_argument("--cli", action="store_true", help="启动命令行对话模式")
    args = parser.parse_args()

    load_model()
    if args.api:
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000)
    elif args.web:
        start_gradio()
    else:
        start_cli()