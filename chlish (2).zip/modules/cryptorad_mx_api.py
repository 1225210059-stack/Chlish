import json
import hashlib
from main import generate_text
from modules.self_growth import ChlishSelfGrowth

# 全局自生长实例
self_growth = ChlishSelfGrowth()

class CryptoradMXAPI:
    def __init__(self):
        # 系统提示词，严格遵循CRYPTORAD-MX架构规范
        self.system_prompt = """
        你是CRYPTORAD-MX复合密码本加密系统的专属AI助手，精通军用级密码学、Shamir门限秘密共享、非线性加密、反逆向工程、抗AI拟合攻击、沙箱模拟渗透测试。
        所有输出必须100%符合CRYPTORAD-MX的6层复合密码本架构规范，确保代码可直接被CradMXInterpreter解释器加载运行，无语法错误、无原理性漏洞。
        禁止输出任何有安全漏洞的加密逻辑，禁止输出不符合国密/军用级安全标准的代码，所有生成内容必须适配最高安全级别要求。
        """

    def generate_cipher_book(self, threshold: int = 3, total_shards: int = 5, security_level: str = "high"):
        """生成完整的CRYPTORAD-MX复合密码本，直接适配原解释器"""
        prompt = self.system_prompt + f"""
        请生成一套完整的CRYPTORAD-MX复合密码本，严格遵循以下要求：
        1. Shamir门限架构：Shamir({threshold},{total_shards})，必须满足门限规则，少于阈值分片无法还原任何有效信息
        2. 安全级别：{security_level}，高安全级别必须内置抗AI拟合、反沙箱爆破、硬件环境绑定、蜜罐陷阱机制
        3. 必须包含完整6层密码本：
           - 根密钥密码本(.root.cb)：包含门限配置、签名算法、解释器哈希校验、报文头规则
           - 分片映射密码本(.shard.cb)：共{total_shards}个，每个仅包含不完整的映射碎片，无完整解码信息
           - 耦合规则密码本(.link.cb)：定义分片组合顺序、非线性运算规则、动态更新规则，对应电台跳频规则
           - 环境校验密码本(.env.cb)：硬件指纹绑定规则、匹配阈值、不匹配触发动作
           - 一次一密临时密码本(.otp.cb)：动态生成规则、销毁规则
           - 蜜罐陷阱密码本(.honey.cb)：虚假映射表、触发条件、对抗性样本规则
        4. 所有密码本格式必须为标准JSON，可直接被CradMXInterpreter加载，无需二次修改
        直接输出完整的密码本JSON结构，无需额外解释、无多余文字。
        """
        response = generate_text(prompt, max_new_tokens=8192, temperature=0.3)
        # 自动收集到自生长数据，持续优化生成效果
        self_growth.collect_feedback_data(prompt, response, "", is_positive=True)
        return response

    def obfuscate_code_with_cryptorad(self, code: str, complexity: int = 3):
        """基于CRYPTORAD-MX规则的代码混淆，抗逆向、抗AI拟合"""
        prompt = self.system_prompt + f"""
        请基于CRYPTORAD-MX复合密码本架构，对以下Python代码进行最高安全级别的混淆，复杂度等级{complexity}（1-5级，5级最高）：
        ```python
        {code}