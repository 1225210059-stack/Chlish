import os
import json
import torch
from datetime import datetime
from datasets import Dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import TrainingArguments, Trainer, DataCollatorForLanguageModeling

class ChlishSelfGrowth:
    def __init__(self, llm=None, tokenizer=None):
        self.llm = llm
        self.tokenizer = tokenizer
        self.data_dir = "./growth_data"
        self.lora_output_dir = "./growth_dora"
        self.stable_version_path = "./stable_version"
        # 自动创建目录
        for path in [self.data_dir, self.lora_output_dir, self.stable_version_path]:
            os.makedirs(path, exist_ok=True)
        # DoRA优化配置，比传统LoRA效果更好、显存占用更低
        self.dora_config = LoraConfig(
            r=8,
            lora_alpha=16,
            target_modules=["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
            use_dora=True,
            init_lora_weights="gaussian"
        )

    def collect_feedback_data(self, user_prompt: str, model_response: str, user_feedback: str, is_positive: bool):
        """收集用户反馈数据，作为自生长训练素材"""
        data_item = {
            "instruction": user_prompt,
            "output": model_response if is_positive else user_feedback,
            "feedback_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "is_positive": is_positive
        }
        # 按天保存数据，避免单文件过大
        file_path = os.path.join(self.data_dir, f"growth_data_{datetime.now().strftime('%Y%m%d')}.jsonl")
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(data_item, ensure_ascii=False) + "\n")
        print(f"✅ 已收集自生长数据，当前累计：{len(open(file_path).readlines())}条")

    def load_growth_dataset(self):
        """加载并预处理自生长数据集，自动格式化对话格式"""
        all_data = []
        for file in os.listdir(self.data_dir):
            if file.endswith(".jsonl"):
                with open(os.path.join(self.data_dir, file), "r", encoding="utf-8") as f:
                    for line in f:
                        item = json.loads(line)
                        # 格式化对话模板，适配Qwen模型
                        all_data.append({
                            "text": f"<|im_start|>user\n{item['instruction']}<|im_end|>\n<|im_start|>assistant\n{item['output']}<|im_end|>"
                        })
        if len(all_data) == 0:
            raise Exception("无可用的自生长训练数据")
        dataset = Dataset.from_list(all_data)
        return dataset.train_test_split(test_size=0.1)

    def _backup_stable_version(self):
        """备份当前稳定版本，支持一键回滚"""
        import shutil
        from main import MODEL_ENCRYPTED_PATH, ROOT_CB_PATH, ENV_CB_PATH
        backup_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(self.stable_version_path, backup_id)
        os.makedirs(backup_dir, exist_ok=True)
        # 备份核心文件
        if os.path.exists(MODEL_ENCRYPTED_PATH):
            shutil.copytree(MODEL_ENCRYPTED_PATH, os.path.join(backup_dir, "model_encrypted"))
        shutil.copy2(ROOT_CB_PATH, backup_dir)
        shutil.copy2(ENV_CB_PATH, backup_dir)
        print(f"✅ 当前稳定版本已备份，备份ID：{backup_id}")
        return backup_id

    def _rollback_stable_version(self, backup_id: str):
        """一键回滚到历史稳定版本，10秒内完成"""
        import shutil
        from main import MODEL_ENCRYPTED_PATH, ROOT_CB_PATH, ENV_CB_PATH
        backup_dir = os.path.join(self.stable_version_path, backup_id)
        if not os.path.exists(backup_dir):
            print("❌ 无可用的稳定版本备份")
            return False
        # 还原备份文件
        if os.path.exists(os.path.join(backup_dir, "model_encrypted")):
            if os.path.exists(MODEL_ENCRYPTED_PATH):
                shutil.rmtree(MODEL_ENCRYPTED_PATH)
            shutil.copytree(os.path.join(backup_dir, "model_encrypted"), MODEL_ENCRYPTED_PATH)
        shutil.copy2(os.path.join(backup_dir, "test_master.root.cb"), ROOT_CB_PATH)
        shutil.copy2(os.path.join(backup_dir, "test_target.env.cb"), ENV_CB_PATH)
        print("✅ 已一键回滚到上一个稳定版本")
        return True

    def incremental_train_dora(self):
        """DoRA增量自训练，速度更快、效果更好、显存占用更低"""
        print("="*50)
        print("🚀 启动Chlish大模型DoRA自生长增量训练")
        print("="*50)
        # 校验模型是否加载
        if self.llm is None or self.tokenizer is None:
            from main import llm, tokenizer
            self.llm = llm
            self.tokenizer = tokenizer
        # 加载数据集
        try:
            dataset = self.load_growth_dataset()
        except Exception as e:
            print(f"❌ 数据集加载失败：{str(e)}")
            return False
        # 数据量校验，至少10条有效数据才启动训练
        if len(dataset["train"]) < 10:
            print("⚠️  自生长数据不足10条，暂不启动训练")
            return False
        # 备份当前稳定版本
        backup_id = self._backup_stable_version()
        # 准备模型训练
        model = self.llm.model
        model.train()
        model = prepare_model_for_kbit_training(model)
        model = get_peft_model(model, self.dora_config)
        # 打印可训练参数
        trainable_params, all_param = model.get_nb_trainable_parameters()
        print(f"✅ 可训练参数：{trainable_params/1e6:.2f}M | 总参数：{all_param/1e9:.2f}B | 占比：{100 * trainable_params / all_param:.4f}%")
        # 训练参数配置，收敛更快、显存占用更低
        training_args = TrainingArguments(
            output_dir=self.lora_output_dir,
            per_device_train_batch_size=4,
            gradient_accumulation_steps=2,
            learning_rate=1e-4,
            num_train_epochs=3,
            logging_steps=10,
            save_strategy="epoch",
            optim="paged_adamw_8bit",
            fp16=True,
            report_to="none",
            gradient_checkpointing=True,
            max_grad_norm=0.3,
            warmup_ratio=0.05,
            save_safetensors=True
        )
        # 数据整理器
        data_collator = DataCollatorForLanguageModeling(tokenizer=self.tokenizer, mlm=False)
        # 启动训练
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=dataset["train"],
            eval_dataset=dataset["test"],
            data_collator=data_collator,
        )
        trainer.train()
        # 效果验证
        eval_result = trainer.evaluate()
        eval_loss = eval_result["eval_loss"]
        print(f"📊 训练完成，最终验证集Loss：{eval_loss:.4f}")
        # 效果不达标自动回滚
        if eval_loss > 0.3:
            print(f"⚠️  训练效果不达标，自动回滚到稳定版本：{backup_id}")
            self._rollback_stable_version(backup_id)
            return False
        # 保存并合并权重，重新加密绑定MX密码本
        trainer.model.save_pretrained(os.path.join(self.lora_output_dir, "final_dora"))
        model = model.merge_and_unload()
        # 重新加密权重，绑定MX复合密码本
        from main import MODEL_RAW_PATH, mx_model_crypto
        os.makedirs(MODEL_RAW_PATH, exist_ok=True)
        model.save_pretrained(MODEL_RAW_PATH)
        self.tokenizer.save_pretrained(MODEL_RAW_PATH)
        mx_model_crypto.encrypt_model_weights()
        # 更新全局模型
        self.llm.model = model
        print("🎉 自生长训练完成，模型已更新，越用越适配你的场景")
        print("="*50)
        return True