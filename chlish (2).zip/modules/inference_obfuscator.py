import os
import hashlib
import random
import torch
from datetime import datetime

class MXInferenceObfuscator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        self.otp_key = None
        self.token_mapping = {}
        self.reverse_mapping = {}

    def generate_otp_mapping(self):
        """生成一次一密token混淆映射，绑定本次会话，执行完即销毁"""
        self.otp_key = hashlib.sha256(os.urandom(32) + datetime.now().isoformat().encode()).hexdigest()
        vocab_size = self.tokenizer.vocab_size
        # 生成随机token置换映射，无固定规律
        token_ids = list(range(vocab_size))
        random.seed(int(self.otp_key, 16) % (2**32 - 1))
        shuffled_ids = token_ids.copy()
        random.shuffle(shuffled_ids)
        # 构建双向映射
        self.token_mapping = {original: shuffled for original, shuffled in zip(token_ids, shuffled_ids)}
        self.reverse_mapping = {shuffled: original for original, shuffled in zip(token_ids, shuffled_ids)}
        return self.otp_key

    def obfuscate_input_tokens(self, input_ids: torch.Tensor) -> torch.Tensor:
        """输入token混淆，AI无法通过token序列拟合加密规律"""
        obfuscated_ids = input_ids.clone()
        for i in range(obfuscated_ids.shape[1]):
            original_id = obfuscated_ids[0, i].item()
            obfuscated_ids[0, i] = self.token_mapping.get(original_id, original_id)
        return obfuscated_ids

    def restore_output_tokens(self, output_ids: torch.Tensor) -> torch.Tensor:
        """输出token还原，仅本次会话有效，会话结束映射即失效"""
        restored_ids = output_ids.clone()
        for i in range(restored_ids.shape[1]):
            obfuscated_id = restored_ids[0, i].item()
            restored_ids[0, i] = self.reverse_mapping.get(obfuscated_id, obfuscated_id)
        return restored_ids

    def add_adversarial_watermark(self, text: str) -> str:
        """添加对抗性隐形水印，干扰AI拟合，不影响人类阅读"""
        zero_width_chars = ["\u200B", "\u200C", "\u200D", "\uFEFF"]
        watermarked_text = ""
        random.seed(int(self.otp_key, 16) % (2**32 - 1))
        for char in text:
            watermarked_text += char
            if random.random() < 0.08:
                watermarked_text += random.choice(zero_width_chars)
        return watermarked_text

    def destroy_otp(self):
        """销毁本次一次性密码本，用完即毁，无历史痕迹留存"""
        self.otp_key = None
        self.token_mapping = {}
        self.reverse_mapping = {}
        import gc
        gc.collect()