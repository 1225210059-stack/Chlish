import os
import re
import json
import hashlib
import psutil
import torch
from datetime import datetime


class SecurityDefense:
    def __init__(self, root_cb_path: str, env_cb_path: str):
        """
        安全防御核心类，完全适配CRYPTORAD-MX根密码本结构
        :param root_cb_path: 根密钥密码本路径（你提供的test_master.root.cb）
        :param env_cb_path: 环境校验密码本路径
        """
        self.root_cb_path = root_cb_path
        self.env_cb_path = env_cb_path
        self.audit_log_dir = "./audit_logs"
        # 自动创建日志目录，无目录不会报错
        os.makedirs(self.audit_log_dir, exist_ok=True)
        
        # 恶意指令正则（加固防绕过，无匹配崩溃问题）
        self.malicious_patterns = [
            r"rm\s+-rf\s+/",
            r"mkfs\s+",
            r":\(\)\{ :\|:&\s*\};\s*:",
            r"wget\s+http.*\|.*sh",
            r"curl\s+http.*\|.*sh",
            r"base64\s+-d.*\|.*sh",
            r"chmod\s+777\s+/",
            r"dd\s+if=/dev/.*\s+of=/dev/"
        ]
        
        # 加密实例单例缓存，解决重复初始化、循环导入问题
        self._crypto_instance = None
        # 预加载根密码本，提前校验文件有效性
        self._root_cb_data = self._load_root_cb()

    def _load_root_cb(self):
        """预加载根密码本，提前处理文件缺失/格式错误，避免后续崩溃"""
        try:
            if not os.path.exists(self.root_cb_path):
                return {}
            with open(self.root_cb_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _get_crypto_instance(self):
        """延迟加载加密实例，彻底解决循环导入问题，无导入崩溃"""
        if self._crypto_instance is None:
            try:
                # 延迟导入，避免启动时循环导入崩溃
                from modules.model_crypto import MXModelCrypto
                self._crypto_instance = MXModelCrypto(self.root_cb_path, self.env_cb_path)
            except Exception as e:
                # 导入失败也不会崩溃，仅返回None，不影响核心功能
                self._crypto_instance = None
        return self._crypto_instance

    def _write_audit_log(self, event_type: str, event_desc: str, risk_level: str):
        """跨平台兼容审计日志，无写入崩溃、无权限报错"""
        # 安全获取CPU标识，彻底解决None值崩溃问题
        try:
            cpu_freq_info = psutil.cpu_freq()
            cpu_freq_value = cpu_freq_info.current if (cpu_freq_info and cpu_freq_info.current) else "0"
            cpu_raw_str = str(cpu_freq_value)
        except Exception:
            cpu_raw_str = "unknown_cpu"

        # 生成CPU唯一标识
        cpu_serial = hashlib.sha256(cpu_raw_str.encode("utf-8")).hexdigest()[:16]
        
        # 日志条目，无空值字段
        log_item = {
            "event_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "event_type": event_type,
            "event_desc": event_desc,
            "risk_level": risk_level,
            "pid": os.getpid(),
            "cpu_serial": cpu_serial
        }

        # 日志文件路径
        log_file = os.path.join(self.audit_log_dir, f"audit_{datetime.now().strftime('%Y%m%d')}.log")
        
        # 写入日志，全异常捕获，无权限/磁盘满也不会崩溃
        try:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_item, ensure_ascii=False) + "\n")
        except Exception:
            pass

        # 仅Linux系统设置只读权限，Windows跳过，无兼容性报错
        if os.name != "nt":
            try:
                os.chmod(log_file, 0o400)
            except Exception:
                pass

    def detect_debugger(self):
        """跨平台调试器/沙箱检测，无系统调用崩溃、无误杀"""
        # 1. Linux ptrace调试检测（仅Linux执行，Windows跳过）
        if os.name == "posix":
            try:
                with open("/proc/self/status", "r", encoding="utf-8") as f:
                    status_content = f.read()
                # 正则精准匹配TracerPid，解决空格/制表符不匹配问题
                tracer_match = re.search(r"TracerPid\s*:\s*(\d+)", status_content)
                if tracer_match and tracer_match.group(1) != "0":
                    self._write_audit_log("调试器检测", "检测到系统级ptrace调试器附着", "高危")
                    return True
            except Exception:
                pass

        # 2. Python代码级调试器检测（全平台兼容）
        try:
            import sys
            if sys.gettrace() is not None:
                self._write_audit_log("调试器检测", "检测到Python调试器断点附着", "高危")
                return True
        except Exception:
            pass

        # 3. 虚拟机/沙箱环境检测（无root权限也不会崩溃，无误杀WSL）
        vm_keywords = ["virtualbox", "vmware", "qemu", "kvm", "hyper-v"]
        try:
            system_manufacturer = ""
            if os.name == "posix":
                # 无root权限也能执行，错误直接跳过
                system_manufacturer = os.popen("dmidecode -s system-manufacturer 2>/dev/null").read().lower()
            for keyword in vm_keywords:
                if keyword in system_manufacturer:
                    self._write_audit_log("沙箱检测", f"检测到虚拟机环境：{keyword}", "中危")
                    return True
        except Exception:
            pass

        # 无调试器/沙箱，返回False
        return False

    def filter_malicious_content(self, prompt: str):
        """恶意内容过滤，无空值/超长输入崩溃，防绕过"""
        # 空输入/超长输入拦截
        if prompt is None:
            self._write_audit_log("恶意输入检测", "空输入试探", "中危")
            return True, "输入内容不合法，已被安全拦截"
        if len(prompt) > 30000:
            self._write_audit_log("恶意输入检测", "超长内容溢出试探", "中危")
            return True, "输入内容超出长度限制，已被安全拦截"

        # 恶意正则匹配，无匹配崩溃
        for pattern in self.malicious_patterns:
            if re.search(pattern, prompt, re.IGNORECASE):
                self._write_audit_log("恶意指令检测", f"命中高危恶意规则：{pattern}", "高危")
                return True, "该请求包含恶意/危险指令，已被安全拦截"
        
        # 无恶意内容，返回原始内容
        return False, prompt

    def check_file_integrity(self):
        """核心文件完整性校验，完全适配你提供的根密码本结构，无空值报错"""
        core_file_list = [
            "main.py",
            "modules/model_crypto.py",
            "modules/self_growth.py",
            "modules/security_defense.py",
            self.root_cb_path,
            self.env_cb_path
        ]
        integrity_pass = True
        crypto_instance = self._get_crypto_instance()

        for file_path in core_file_list:
            # 缺失文件检测
            if not os.path.exists(file_path):
                self._write_audit_log("文件完整性校验", f"缺失核心文件：{file_path}", "高危")
                integrity_pass = False
                continue

            # 计算当前文件SHA256哈希，无读取崩溃
            try:
                with open(file_path, "rb") as f:
                    file_content = f.read()
                current_file_hash = hashlib.sha256(file_content).hexdigest()
            except Exception:
                self._write_audit_log("文件完整性校验", f"核心文件读取失败：{file_path}", "高危")
                integrity_pass = False
                continue

            # 对比根密码本中的基准哈希，完全适配你提供的file_integrity空结构
            if crypto_instance and hasattr(crypto_instance, "root_cb"):
                base_hash_dict = crypto_instance.root_cb.get("file_integrity", {})
                base_hash = base_hash_dict.get(file_path, "")
                if base_hash and current_file_hash != base_hash:
                    self._write_audit_log("文件完整性校验", f"核心文件被篡改：{file_path}", "高危")
                    integrity_pass = False

        return integrity_pass

    def lock_model(self):
        """安全版模型锁定，无不可逆锁死密码本的风险，无崩溃"""
        self._write_audit_log("模型锁定", "检测到高危攻击，模型已临时锁定", "紧急")
        
        # 释放模型显存，无全局变量导入崩溃
        try:
            from main import llm
            if llm is not None:
                del llm
        except Exception:
            pass
        
        # 清空CUDA缓存，无GPU环境也不会报错
        try:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
        
        # 密码本只读加固，仅Linux执行，无不可逆锁死
        if os.name != "nt":
            try:
                os.chmod(self.root_cb_path, 0o400)
                os.chmod(self.env_cb_path, 0o400)
            except Exception:
                pass
        
        return True


# 全局单例初始化函数，避免导入时崩溃
def init_security_defense(root_cb_path: str, env_cb_path: str):
    """安全初始化全局防御实例，无导入崩溃"""
    global security_defense
    security_defense = SecurityDefense(root_cb_path, env_cb_path)
    return security_defense

# 全局变量延迟初始化，导入时不会执行任何代码，无启动报错
security_defense: SecurityDefense | None = None