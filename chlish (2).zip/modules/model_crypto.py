import os
import json
import torch
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from shamir_mnemonic import shamir
from main import DEVICE, MODEL_RAW_PATH, MODEL_ENCRYPTED_PATH

# 全局配置
THRESHOLD = 3
TOTAL_SHARDS = 5
AES_KEY_LENGTH = 32

class MXModelCrypto:
    def __init__(self, root_cb_path: str, env_cb_path: str):
        self.root_cb = self._load_json(root_cb_path)
        self.env_cb = self._load_json(env_cb_path)
        self.environment_fingerprint = self._get_hardware_fingerprint()
        self.honey_mode = False
        self._verify_env()

    def _load_json(self, path: str):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _get_hardware_fingerprint(self) -> str:
        import platform
        import uuid
        cpu_serial = hashlib.sha256(platform.processor().encode()).hexdigest()
        disk_uuid = hashlib.sha256(str(uuid.getnode()).encode()).hexdigest()
        bios_serial = hashlib.sha256(platform.release().encode()).hexdigest()
        full_fingerprint = hashlib.sha256(f"{cpu_serial}{disk_uuid}{bios_serial}".encode()).hexdigest()
        return full_fingerprint

    def _verify_env(self):
        bind_fingerprint = self.env_cb["bind_fingerprints"].get("model_fingerprint", "")
        if not bind_fingerprint:
            return
        match_rate = sum(1 for a, b in zip(self.environment_fingerprint, bind_fingerprint) if a == b) / len(bind_fingerprint)
        if match_rate < self.env_cb["verify_rules"]["match_threshold"]:
            self.honey_mode = True
            print("[警告] 环境指纹校验失败，触发蜜罐陷阱模式")

    def _generate_aes_key(self) -> bytes:
        return os.urandom(AES_KEY_LENGTH)

    def encrypt_model_weights(self):
        print("=== 开始CRYPTORAD-MX模型权重分片加密 ===")
        os.makedirs(MODEL_ENCRYPTED_PATH, exist_ok=True)
        # 加载原始模型
        from transformers import AutoModelForCausalLM, AutoTokenizer
        model = AutoModelForCausalLM.from_pretrained(MODEL_RAW_PATH, device_map=DEVICE)
        tokenizer = AutoTokenizer.from_pretrained(MODEL_RAW_PATH)
        model_bytes = json.dumps({k: v.cpu().numpy().tolist() for k, v in model.state_dict().items()}).encode()
        # 生成加密密钥，Shamir分片
        aes_key = self._generate_aes_key()
        key_int = int.from_bytes(aes_key, "big")
        key_shards = shamir.split_secret(THRESHOLD, TOTAL_SHARDS, key_int.to_bytes(32, "big"))
        # 写入分片密码本
        for i in range(TOTAL_SHARDS):
            shard_path = f"./test_cipher_books/map_{i+1}.shard.cb"
            shard_cb = self._load_json(shard_path)
            shard_cb["model_key_shard"] = {
                "shard_id": i+1,
                "shard_value": key_shards[i].hex(),
                "fingerprint": self.environment_fingerprint
            }
            with open(shard_path, "w", encoding="utf-8") as f:
                json.dump(shard_cb, f, indent=2)
        # AES-GCM加密
        nonce = os.urandom(12)
        cipher = Cipher(algorithms.AES(aes_key), modes.GCM(nonce), backend=default_backend())
        encryptor = cipher.encryptor()
        encrypted_model = encryptor.update(model_bytes) + encryptor.finalize()
        # 分片存储
        shard_size = len(encrypted_model) // TOTAL_SHARDS
        for i in range(TOTAL_SHARDS):
            start = i * shard_size
            end = start + shard_size if i != TOTAL_SHARDS-1 else len(encrypted_model)
            shard_data = encrypted_model[start:end]
            with open(os.path.join(MODEL_ENCRYPTED_PATH, f"model_shard_{i+1}.bin"), "wb") as f:
                f.write(nonce + encryptor.tag + shard_data)
        # 写入元数据
        with open(os.path.join(MODEL_ENCRYPTED_PATH, "model_meta.json"), "w", encoding="utf-8") as f:
            json.dump({
                "threshold": THRESHOLD,
                "total_shards": TOTAL_SHARDS,
                "fingerprint": self.environment_fingerprint,
                "root_signature": hashlib.sha256(aes_key + self.environment_fingerprint.encode()).hexdigest()
            }, f, indent=2)
        # 销毁原始明文权重
        import shutil
        if os.path.exists(MODEL_RAW_PATH):
            shutil.rmtree(MODEL_RAW_PATH)
            with open(os.path.join(MODEL_RAW_PATH, "null.bin"), "wb") as f:
                f.write(os.urandom(1024*1024*100))
            shutil.rmtree(MODEL_RAW_PATH)
        print("=== 模型权重加密完成，已绑定CRYPTORAD-MX复合密码本 ===")
        return True

    def decrypt_and_load_model(self, shard_cb_paths: list):
        if self.honey_mode:
            print("[蜜罐模式] 加载虚假模型权重")
            from transformers import AutoModelForCausalLM, AutoTokenizer
            model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-1.8B-Instruct", device_map=DEVICE)
            tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-1.8B-Instruct")
            return model, tokenizer
        # 校验分片数量
        if len(shard_cb_paths) < THRESHOLD:
            raise Exception(f"分片数量不足，至少需要{THRESHOLD}个有效分片")
        # 提取密钥分片
        key_shards = []
        for path in shard_cb_paths[:THRESHOLD]:
            shard_cb = self._load_json(path)
            if "model_key_shard" not in shard_cb:
                raise Exception(f"分片{path}无效，无模型密钥分片")
            if shard_cb["model_key_shard"]["fingerprint"] != self.environment_fingerprint:
                raise Exception(f"分片{path}环境指纹不匹配，已失效")
            key_shards.append(bytes.fromhex(shard_cb["model_key_shard"]["shard_value"]))
        # 恢复密钥
        recovered_key = shamir.recover_secret(key_shards)
        aes_key = recovered_key
        # 校验签名
        meta = self._load_json(os.path.join(MODEL_ENCRYPTED_PATH, "model_meta.json"))
        signature = hashlib.sha256(aes_key + self.environment_fingerprint.encode()).hexdigest()
        if signature != meta["root_signature"]:
            raise Exception("密钥校验失败，分片密码本被篡改")
        # 加载加密分片
        encrypted_model = b""
        nonce = None
        tag = None
        for i in range(TOTAL_SHARDS):
            shard_path = os.path.join(MODEL_ENCRYPTED_PATH, f"model_shard_{i+1}.bin")
            with open(shard_path, "rb") as f:
                shard_data = f.read()
                if i == 0:
                    nonce = shard_data[:12]
                    tag = shard_data[12:28]
                    shard_content = shard_data[28:]
                else:
                    shard_content = shard_data[28:]
                encrypted_model += shard_content
        # 解密
        cipher = Cipher(algorithms.AES(aes_key), modes.GCM(nonce, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        try:
            model_bytes = decryptor.update(encrypted_model) + decryptor.finalize()
        except:
            raise Exception("模型解密失败，密码本无效")
        # 加载模型
        model_dict = json.loads(model_bytes.decode())
        model_tensor_dict = {k: torch.tensor(v).to(DEVICE) for k, v in model_dict.items()}
        from transformers import AutoModelForCausalLM, AutoTokenizer
        model = AutoModelForCausalLM.from_pretrained(
            "Qwen/Qwen2.5-7B-Instruct",
            state_dict=model_tensor_dict,
            device_map=DEVICE,
            torch_dtype=torch.float16
        )
        tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-7B-Instruct")
        # 销毁敏感数据
        del aes_key, model_bytes, encrypted_model, model_dict
        import gc
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        print("✅ 模型解密加载完成，全程无明文权重落地")
        return model, tokenizer