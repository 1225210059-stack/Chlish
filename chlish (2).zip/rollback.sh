#!/bin/bash
set -e
if [ $# -ne 1 ]; then
    echo "使用方法：./rollback.sh 备份版本ID"
    echo "示例：./rollback.sh backup_20260423_153000"
    exit 1
fi

BACKUP_NAME=$1
echo "=================================================="
echo "  Chlish大模型 一键版本回滚脚本"
echo "  回滚目标版本：$BACKUP_NAME"
echo "=================================================="

# 1. 校验备份是否存在
if [ ! -d "./backup/$BACKUP_NAME" ]; then
    echo "❌ 备份版本不存在：./backup/$BACKUP_NAME"
    exit 1
fi
echo "✅ 备份版本校验通过"

# 2. 停止当前运行的服务
echo "[1/4] 正在停止当前运行的服务..."
pkill -f "python main.py" 2>/dev/null || true
pkill -f "uvicorn" 2>/dev/null || true
echo "✅ 服务已停止"

# 3. 还原备份文件
echo "[2/4] 正在还原备份文件..."
if [ -d "./backup/$BACKUP_NAME/model_encrypted" ]; then
    rm -rf ./model_encrypted
    cp -r ./backup/$BACKUP_NAME/model_encrypted ./
fi
if [ -d "./backup/$BACKUP_NAME/test_cipher_books" ]; then
    rm -rf ./test_cipher_books
    cp -r ./backup/$BACKUP_NAME/test_cipher_books ./
fi
if [ -d "./backup/$BACKUP_NAME/modules" ]; then
    rm -rf ./modules
    cp -r ./backup/$BACKUP_NAME/modules ./
fi
if [ -f "./backup/$BACKUP_NAME/main.py" ]; then
    cp ./backup/$BACKUP_NAME/main.py ./
fi
echo "✅ 备份文件还原完成"

# 4. 验证回滚有效性
echo "[3/4] 正在验证回滚有效性..."
source chlish_venv/bin/activate
python -c "
from main import load_model
model, tokenizer = load_model()
print('✅ 模型加载正常，回滚成功')
"
echo "✅ 回滚有效性验证通过"

# 5. 快速安全测试
echo "[4/4] 正在执行快速安全测试..."
python mx_sandbox_test.py --quick

echo "=================================================="
echo "  🎉 一键回滚完成！"
echo "  已恢复到版本：$BACKUP_NAME"
echo "=================================================="