import os
import sys
# 把当前目录加入Python路径，解决模块导入问题
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.security_defense import init_security_defense

# 1. 初始化安全防御实例，适配你的根密码本路径
ROOT_CB_PATH = "./test_cipher_books/test_master.root.cb"
ENV_CB_PATH = "./test_cipher_books/test_target.env.cb"

security = init_security_defense(ROOT_CB_PATH, ENV_CB_PATH)
print("✅ 安全防御实例初始化成功，无报错")

# 2. 测试调试器检测
debug_result = security.detect_debugger()
print(f"✅ 调试器检测完成，结果：{debug_result}")

# 3. 测试恶意内容过滤
malicious_result, malicious_msg = security.filter_malicious_content("rm -rf /")
print(f"✅ 恶意内容过滤完成，结果：{malicious_result}，提示：{malicious_msg}")

# 4. 测试正常内容过滤
normal_result, normal_msg = security.filter_malicious_content("生成一段Shamir门限代码")
print(f"✅ 正常内容过滤完成，结果：{normal_result}，内容：{normal_msg[:20]}...")

# 5. 测试文件完整性校验
integrity_result = security.check_file_integrity()
print(f"✅ 文件完整性校验完成，结果：{integrity_result}")

# 6. 测试模型锁定
lock_result = security.lock_model()
print(f"✅ 模型锁定完成，结果：{lock_result}")

print("\n🎉 全流程测试完成，所有功能无报错、无崩溃！")