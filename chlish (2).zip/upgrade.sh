#!/bin/bash
set -e
echo "=================================================="
echo "  Chlish大模型 一键版本升级脚本"
echo "=================================================="

# 1. 备份当前稳定版本
echo "[1/5] 正在备份当前稳定版本..."
if [ ! -d "./backup" ]; then
    mkdir -p ./backup
fi
backup_name="backup_$(date +%Y%m%d_%H%M%S)"
cp -r ./model_encrypted ./test_cipher_books ./modules ./main.py ./backup/$backup_name 2>/dev/null || true
echo "✅ 备份完成，版本ID：$backup_name"

# 2. 拉取最新代码
echo "[2/5] 正在拉取GitHub最新代码..."
git reset --hard HEAD
git pull origin main
echo "✅ 最新代码拉取完成"

# 3. 更新依赖
echo "[3/5] 正在更新依赖库..."
source chlish_venv/bin/activate
pip install --upgrade -r requirements.txt
echo "✅ 依赖更新完成"

# 4. 校验核心文件完整性
echo "[4/5] 正在校验升级完整性..."
required_files=(
    "main.py"
    "requirements.txt"
    "modules/model_crypto.py"
    "modules/self_growth.py"
)
for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ 升级失败，缺失核心文件：$file"
        exit 1
    fi
done
echo "✅ 升级完整性校验通过"

# 5. 快速安全测试
echo "[5/5] 正在执行快速沙箱安全测试..."
python mx_sandbox_test.py --quick

echo "=================================================="
echo "  🎉 升级完成！当前版本：v1.2.0 旗舰版"
echo "  若升级出现问题，执行以下命令一键回滚："
echo "  chmod +x rollback.sh && ./rollback.sh $backup_name"
echo "=================================================="